/* <<< Release Notice for library >>> */

#include <projects.h>

char const pj_release[]="Rel. 4.4.9, 29 Oct 2004";

const char *pj_get_release()

{
    return pj_release;
}
